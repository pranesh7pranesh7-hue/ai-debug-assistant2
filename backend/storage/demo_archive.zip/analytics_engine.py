def compute_kpis(data):
    return sum(data)
