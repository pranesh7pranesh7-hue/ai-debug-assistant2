def fetch_data():
    return [10, 20, 30]
